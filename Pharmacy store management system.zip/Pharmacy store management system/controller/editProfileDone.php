
<?php
session_start();

?>

<!DOCTYPE html>
<html>

<style>
.error {color: #2BDE1A;}
</style>

<?php
     
     include('../header2.php');

     require_once '../model/model.php';


     $data['Name1']                     =     $_SESSION['name1'];
     $data['Password1']                 =     $_SESSION['pass1'];
     $data['User Name']                =     $_SESSION['username'];


    if (updateUsers($data)) {
        //echo 'Successfully updated!!';
        header('Location:../view/editProfileDone.php');

    } else {
        echo 'You are not allowed to access this page.';    
    }
			
?>
<span class="error"> <b> <h1 align="center" style= "color: #15319d;"><?php echo  "Successfully updated";?></h1> </span>

<body>



</body>

<?php
include('../view/footer.php');;
?>


</html>

<?php
session_start();
?>

<?php
     
     include('../header.php');

     require_once '../model/model.php';


     $data['Name']                     =     $_SESSION['name'];
     $data['Email']                    =     $_SESSION['email']; 
     $data['Gender']                   =     $_SESSION['gender'];
     $data['Dob']                      =     $_SESSION['dob'];  
     $data['User Name']                =     $_SESSION['username'];  
     $data['Password']                 =     $_SESSION['pass'];


    if (addUsers($data)) {
        //echo "success";
        header('location:../view/registrationDone.php');
    } else {
        echo 'You are not allowed to access this page.';    
    }
			
?>

<?php
	echo '
	
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<fieldset >

	    
	     
	    <p align="left" >
	        <a href="../view/homepage.php" style="font-size:22px" >Home</a>&nbsp;&nbsp;&nbsp;
	        <a href="../view/login.php" style="font-size:22px" >Login</a>&nbsp;&nbsp;&nbsp;
	        <a href="../view/registration.php" style="font-size:22px" >Register</a>
	    </p> 
	    <center><img id="headerImage" width="950" height="200" src="../bg.png" ></center>
	</fieldset>
	';

?>
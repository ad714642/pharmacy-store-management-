<?php
	echo '
	
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<fieldset>

	    
		

	    <p align="left" >
	    	

	        <a href="../view/homepage2.php" style="font-size:22px" >Home</a>&nbsp;&nbsp;&nbsp;
	        <a href="../view/myProfile.php" style="font-size:22px" >My profile</a>&nbsp;&nbsp;&nbsp;
	        <a href="../view/editProfile.php" style="font-size:22px" >Edit profile</a>&nbsp;&nbsp;&nbsp;
	        <a href="../view/checkProduct.php" style="font-size:22px" > Buy Product  </a>&nbsp;&nbsp;&nbsp;
	        <a href="../view/cartList.php" style="font-size:22px" >Cart List</a>&nbsp;&nbsp;&nbsp;
	        <a href="../view/logout.php" style="font-size:22px" >Log Out</a>
	        
	    </p> 
	    <center><img id="headerImage" width="400" height="100" src="../bg.png" ></center> 
	    
	</fieldset>
	';

?>
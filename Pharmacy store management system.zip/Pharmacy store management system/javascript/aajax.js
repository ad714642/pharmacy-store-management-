function getAll() {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("livesearch").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","../controller/getAllEmployee.php?",true);
    xmlhttp.send();
    return;
}





function getAllProduct() {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("livesearch").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","../controller/getAllProduct.php?",true);
    xmlhttp.send();
    return;
}


  function showResultProduct(str) {


    //document.getElementById("search").style.backgroundColor="RED";
    if (str.length==0) {

      //document.getElementById("livesearch").innerHTML=""; 
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          document.getElementById("livesearch").innerHTML = this.responseText;
        }
      };
      xmlhttp.open("GET","../controller/getAllProduct.php?",true);
      xmlhttp.send();
        return;
    } else {

    document.getElementById("livesearch").innerHTML=""; 
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("livesearch").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","../controller/getProduct.php?q="+str,true);
    xmlhttp.send();
  }
}



function addCart(str) {

  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    alert("added to cart");
    //document.getElementById("livesearch").innerHTML = this.responseText;
    //getAll();

  }
  };
  xmlhttp.open("GET","../controller/addCartDone.php?q="+str,true);
  xmlhttp.send();

  






    console.log(str);
    //document.getElementById("demo").style.color = "red";
}



function getCartlist() {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("livesearch").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","../controller/getCartlist.php?",true);
    xmlhttp.send();
    return;
}



function deleteCart(str) {

  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    document.getElementById("livesearch").innerHTML = this.responseText;
    getCartlist();
  }
  };
  xmlhttp.open("GET","../controller/deleteCartDone.php?q="+str,true);
  xmlhttp.send();

    console.log(str);
}

function buy() {
  alert("payment method must be added");
}
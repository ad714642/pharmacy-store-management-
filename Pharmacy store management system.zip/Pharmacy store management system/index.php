<?php 

header('Location:view/homepage.php');

 ?>
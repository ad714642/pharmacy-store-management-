


<?php

	echo "<footer><fieldset><p align=center><br>Copyright arnabdas@gmail.com <span>&#169;</span>2021</p></fieldset></footer>";

?>
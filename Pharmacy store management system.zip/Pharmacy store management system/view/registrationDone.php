
<?php
session_start();

if(!empty($_SESSION['username'])){


}
else
    header('Location:registration.php');
?>

<!DOCTYPE html>
<html>

<style>
.error {color: #2BDE1A;}
</style>

<?php
include('../header.php');;
?>


<span class="error"> <b> <h1 align="center" style= "color: #15319d;"><?php echo  "Thanks for Registration";?></h1> </span>

<body>



</body>

<?php
include('../view/footer.php');;
?>


</html>
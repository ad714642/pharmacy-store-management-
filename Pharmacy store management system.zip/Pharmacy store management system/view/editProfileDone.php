
<?php
session_start();

if(isset($_SESSION['username'])){


}
else{

    header('location:login.php');
}

?>


<?php
include('../header2.php');;
?>

<!DOCTYPE html>
<html>

<style>
.error {color: #2BDE1A;}
</style>


<span class="error"> <b> <h1 align="center" style= "color: #15319d;"><?php echo  "Successfully updated";?></h1> </span>

<body>



</body>

<?php
include('../view/footer.php');;
?>


</html>
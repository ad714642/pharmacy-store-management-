
<?php
session_start();

if(isset($_SESSION['username'])){


}
else{

    header('location:login.php');
}

?>



<?php  
    require_once '../controller/readData.php';
    $user = fetchUsers($_SESSION['username']);

?>




<!DOCTYPE html>
<html>



<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../css/styles.css">
  <title>My profile</title>
</head>


<style>
    .error {color: black;}

    table, th, td {
          border: 4px solid black;
          
        }

    th, td {
        padding: 4px;
    }


</style>




 <?php 
    include('../header2.php')?>
 <?php

 
?>
<fieldset>
<p><br></p>
<div  align="center">
<table id="content" align="center" style="color:#0F9934;">
    <tr>

    </tr>



            <tr>
                <td><h4>Name: <?php echo $user['Name'] ?></h4> </td>
            <tr>
            <tr>
                <td><h4>Email Adress : <?php echo $user['Email'] ?></h4></td>
            </tr>
            <tr>
                <td><h4>User Name : <?php echo $user['User_Name'] ?></h4></td>
            </tr>
            <tr>
                <td><h4> Date Of Birth : <?php echo $user['Dob'] ?></h4></td>
            </tr>
            <tr>
                <td><h4>Gender : <?php echo $user['Gender'] ?></h4></td>
            </tr>
        <?php //endforeach; ?>
</table>

</div>
<p><br></p>
</fieldset>





</body>


  <?php include('footer.php');?>

  </html>
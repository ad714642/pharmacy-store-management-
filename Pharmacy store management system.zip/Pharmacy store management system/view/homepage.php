
<!DOCTYPE html>

<style>
.error {color: #FF0000;}
</style>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <title></title>
</head>


 <?php include('../header.php')?>
<body>


    <fieldset id="welcomeContent">

        <p><br></p><p><br></p>
        <h1 align="center" style= "color: #0F9934;">Please sign up or Log in </h1> 
        


    
    <p><br></p><p><br></p>
    <p><br><br></p>
    </fieldset>
</body>


<?php include('footer.php')?>

</html>

